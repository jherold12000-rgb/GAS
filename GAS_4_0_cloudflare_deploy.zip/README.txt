Déploiement Cloudflare Workers — GAS 4.0
==========================================

1. Dézippez ce fichier dans un dossier sur votre machine.
2. Ouvrez un terminal DANS ce dossier (celui qui contient wrangler.toml).
3. Installez wrangler si besoin :
   npm install -g wrangler

4. Connectez-vous à votre compte Cloudflare :
   wrangler login

5. Créez le namespace KV (une seule fois) :
   wrangler kv namespace create GAS_KV

   Cela retourne un id du type :
   { binding = "GAS_KV", id = "abcd1234..." }

   Ouvrez wrangler.toml et remplacez COLLER_ICI_ID_DU_NAMESPACE par cet id.

6. Définissez les secrets (ne jamais les mettre en clair dans wrangler.toml) :
   wrangler secret put GAS_ADMIN_KEY
   wrangler secret put GAS_LICENSE_SECRET
   wrangler secret put GAS_PERMANENT_KEY

7. Déployez :
   wrangler deploy

8. Une fois déployé, Cloudflare affiche une URL du type :
   https://gas-server.votre-compte.workers.dev

   Dans l'application GAS_4_0.html, allez dans Paramètres > Serveur GAS
   et saisissez : https://gas-server.votre-compte.workers.dev/api

Important : ce déploiement se fait via la commande "wrangler deploy" en
ligne de commande, PAS via un simple glisser-déposer du ZIP dans le
tableau de bord Cloudflare — c'est cela qui causait l'erreur
"wrangler.toml introuvable".
