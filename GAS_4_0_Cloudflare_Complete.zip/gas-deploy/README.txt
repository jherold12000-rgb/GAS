Déploiement Cloudflare Workers — GAS 4.0 avec Interface Web
============================================================

STRUCTURE DU PROJET
- worker.js : Code serveur (API et gestion KV)
- public/index.html : Interface web GPAS 4.0
- wrangler.toml : Configuration Cloudflare

ÉTAPES DE DÉPLOIEMENT

1. Dézippez ce fichier dans un dossier sur votre machine.

2. Ouvrez un terminal DANS ce dossier (celui qui contient wrangler.toml).

3. Installez wrangler si besoin :
   npm install -g wrangler

4. Connectez-vous à votre compte Cloudflare :
   wrangler login

5. Créez le namespace KV (une seule fois) :
   wrangler kv namespace create GAS_KV

   Cela retourne un id du type :
   { binding = "GAS_KV", id = "abcd1234..." }

   Ouvrez wrangler.toml et remplacez COLLER_ICI_ID_DU_NAMESPACE par cet id.

6. Définissez les secrets (ne jamais les mettre en clair dans wrangler.toml) :
   wrangler secret put GAS_ADMIN_KEY
   wrangler secret put GAS_LICENSE_SECRET
   wrangler secret put GAS_PERMANENT_KEY

   Entrez vos clés secrètes quand le terminal les demande.

7. Déployez :
   wrangler deploy

8. Une fois déployé, Cloudflare affiche une URL du type :
   https://gas-server.votre-compte.workers.dev

   L'application GPAS 4.0 sera accessible directement à cette URL.

ACCÈS À L'APPLICATION

Après déploiement, ouvrez simplement :
https://gas-server.votre-compte.workers.dev

L'interface complète de GPAS 4.0 se charge depuis le serveur Cloudflare.
