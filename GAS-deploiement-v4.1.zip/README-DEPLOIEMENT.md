# GAS — Gestion Administration Scolaire — Paquet de déploiement (v4.1)

## Contenu du paquet
- `index.html` — l'application complète (monofichier)
- `manifest.json` — manifeste PWA (nom, icônes, couleurs)
- `sw.js` — service worker (fonctionnement hors-ligne après premier chargement)
- `favicon.ico` — icône multi-taille (16/32/48 px)
- `icon-*.png` — icônes PWA (72 à 512 px) générées depuis le logo GAS
- `icon-maskable-*.png` — variantes "maskable" (Android adaptive icons)
- `apple-touch-icon.png` — icône pour iOS/Safari

## Déploiement
1. Copier **tous les fichiers de ce dossier** (à plat, sans sous-dossier) sur l'hébergement choisi (Netlify, serveur web classique, etc.). Les chemins dans `index.html` et `manifest.json` sont relatifs (`./`), donc tous les fichiers doivent rester au même niveau.
2. Servir via **HTTPS** (obligatoire pour que le service worker et l'installation PWA fonctionnent). Le mode `file://` local fonctionne pour un test rapide, mais désactive le service worker et l'installation en PWA.
3. Aucune base de données ni build n'est nécessaire : c'est un site statique.

## Mise à jour d'une version future
- Remplacer `index.html` par la nouvelle version.
- Incrémenter `CACHE_NAME` dans `sw.js` (ex. `gas-cache-v4.2`) pour forcer les navigateurs à recharger les fichiers au lieu de servir l'ancien cache.
- Mettre à jour le champ `version` dans `manifest.json` si vous utilisez la vérification de mise à jour intégrée à l'app (§ "Vérifier maintenant").

## Vérification après déploiement
- Ouvrir le site en HTTPS, vérifier dans les outils développeur (Application/Manifest) que le manifeste et le service worker sont bien détectés.
- Tester "Installer l'application" (icône dans la barre d'adresse ou menu du navigateur).
- Couper le réseau et recharger la page : l'app doit continuer à fonctionner (données stockées en IndexedDB).
