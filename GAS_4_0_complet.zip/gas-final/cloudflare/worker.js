/* ─────────────────────────────────────────────────────────────────────────
   GAS 4.0 — Variante Cloudflare Workers.

   Le dossier server/ (Node + Express + fichier JSON) ne fonctionne pas sur
   Cloudflare Workers : Workers n'a pas de système de fichiers persistant
   et n'exécute pas un vrai processus Node. Ce fichier réimplémente les
   mêmes 10 fonctions avec le même comportement, en utilisant Workers KV
   comme stockage à la place du fichier JSON.

   Déploiement :
   1. npm install -g wrangler
   2. wrangler kv namespace create GAS_KV
      (copier l'id retourné dans wrangler.toml, voir plus bas)
   3. wrangler deploy

   URL à saisir dans les Paramètres de l'application GAS une fois déployé :
   https://votre-worker.votre-compte.workers.dev/api
   ───────────────────────────────────────────────────────────────────────── */

const MAX_TERMINAUX = 3;
const NUMEROS_AUTORISES = ['001', '002', '003'];
const LOCKOUT_HEURES = 48;
const TRIAL_DAYS = 60;
const MAX_OPERATIONS_PAR_APPEL = 500;
const MAX_OPERATIONS_RETOURNEES = 500;

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json; charset=utf-8'
  };
}
function json(statusCode, body) {
  return new Response(JSON.stringify(body || {}), { status: statusCode, headers: corsHeaders() });
}
function ok(body) { return json(200, { ok: true, ...body }); }
function fail(statusCode, message, extra) { return json(statusCode, { ok: false, message, ...extra }); }

function hex(nBytes) {
  const bytes = new Uint8Array(nBytes);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
}
async function hmacHex(secret, texte) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(texte));
  return Array.from(new Uint8Array(sig), b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
}
function deriveSigle(sigle, nom) {
  const clean = s => (s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  let s = clean(sigle);
  if (s.length >= 2) return s.slice(0, 6);
  const mots = (nom || '').trim().split(/\s+/).filter(Boolean);
  s = mots.map(m => m[0]).join('').toUpperCase().replace(/[^A-Z0-9]/g, '');
  return s.length >= 2 ? s.slice(0, 6) : 'ETB';
}
function nowIso() { return new Date().toISOString(); }
function dansLeFutur(dateIso) { return !!dateIso && new Date(dateIso).getTime() > Date.now(); }
function prochainNumeroLibre(terminaux) {
  const occupes = new Set(terminaux.filter(t => t.statut === 'actif').map(t => t.numeroTerminal));
  return NUMEROS_AUTORISES.find(n => !occupes.has(n)) || null;
}
function computeLicenceServeur(etab) {
  if (!etab) return { statut: 'EXPIRE', joursRestants: 0 };
  if (etab.statutLicence === 'PERMANENTE') return { statut: 'PERMANENTE', joursRestants: null };
  if (etab.statutLicence === 'ACTIVE') return { statut: 'ACTIVE', joursRestants: null };
  const fin = etab.dateFinEssai ? new Date(etab.dateFinEssai).getTime() : null;
  if (!fin) return { statut: 'EXPIRE', joursRestants: 0 };
  const joursRestants = Math.ceil((fin - Date.now()) / 86400000);
  if (joursRestants <= 0) return { statut: 'EXPIRE', joursRestants: 0 };
  if (joursRestants <= 7) return { statut: 'ESSAI_EXPIRANT', joursRestants };
  return { statut: 'ESSAI', joursRestants };
}

async function getEtab(env, id) { const v = await env.GAS_KV.get(`etablissement/${id}`); return v ? JSON.parse(v) : null; }
async function putEtab(env, id, data) { await env.GAS_KV.put(`etablissement/${id}`, JSON.stringify(data)); }
async function getTerm(env, id) { const v = await env.GAS_KV.get(`terminaux/${id}`); return v ? JSON.parse(v) : []; }
async function putTerm(env, id, t) { await env.GAS_KV.put(`terminaux/${id}`, JSON.stringify(t)); }

async function genererIdEtablissementUnique(env, sigle, nom) {
  const prefixe = deriveSigle(sigle, nom);
  for (let i = 0; i < 20; i++) {
    const id = `GAS-${prefixe}-${hex(3)}`;
    if (!(await getEtab(env, id))) return id;
  }
  return `GAS-${prefixe}-${hex(5)}`;
}

const ROUTES = {
  async 'register-etablissement'(body, env) {
    const nom = (body.nom || '').trim();
    const idInstallationTerminal = (body.idInstallationTerminal || '').trim();
    if (!nom) return fail(400, "Le nom de l'établissement est obligatoire.");
    if (!idInstallationTerminal) return fail(400, "Identité d'installation manquante.");

    /* Continuité d'un établissement d'abord créé en local (mode local
       d'abord) : on garde l'ID déjà généré côté client s'il est encore
       libre, plutôt que d'en attribuer un nouveau. */
    const idSouhaite = (body.idEtablissementSouhaite || '').trim().toUpperCase();
    let idEtablissement;
    if (idSouhaite && !(await getEtab(env, idSouhaite))) idEtablissement = idSouhaite;
    else idEtablissement = await genererIdEtablissementUnique(env, body.sigle, nom);

    const now = nowIso();
    /* Si l'établissement existait déjà localement, on part de sa date
       réelle de première installation plutôt que de "maintenant", pour
       ne pas redémarrer le compteur de 60 jours à zéro. */
    let dateDebutEssai = now;
    const dateSouhaitee = body.dateDebutEssaiSouhaitee ? new Date(body.dateDebutEssaiSouhaitee) : null;
    if (dateSouhaitee && !isNaN(dateSouhaitee.getTime()) && dateSouhaitee.getTime() <= Date.now()) {
      const plusAncienneAcceptee = Date.now() - TRIAL_DAYS * 86400000;
      dateDebutEssai = new Date(Math.max(dateSouhaitee.getTime(), plusAncienneAcceptee)).toISOString();
    }
    const dateFinEssai = new Date(new Date(dateDebutEssai).getTime() + TRIAL_DAYS * 86400000).toISOString();

    await putEtab(env, idEtablissement, {
      idEtablissement, nom, sigle: (body.sigle || '').trim(), commune: (body.commune || '').trim(),
      departement: (body.departement || '').trim(), telephone: (body.telephone || '').trim(),
      dateCreation: now, dateDebutEssai, dateFinEssai, versionGAS: body.versionGAS || null,
      statutLicence: 'ESSAI', dateActivation: null
    });
    const numeroTerminal = '001';
    const idTerminal = `${idEtablissement}-${numeroTerminal}`;
    const jeton = hex(24);
    await putTerm(env, idEtablissement, [{
      idTerminal, idEtablissement, numeroTerminal, idInstallationTerminal,
      typeTerminal: body.typeTerminal || 'Inconnu', jeton, versionGAS: body.versionGAS || null,
      dateEnregistrement: now, derniereConnexion: now, derniereSynchronisation: null,
      statut: 'actif', verrouille: null
    }]);
    return ok({ idEtablissement, idTerminal, numeroTerminal, jeton });
  },

  async 'register-terminal'(body, env) {
    const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
    const idInstallationTerminal = (body.idInstallationTerminal || '').trim();
    if (!idEtablissement) return fail(400, 'ID établissement manquant.');
    if (!idInstallationTerminal) return fail(400, "Identité d'installation manquante.");
    const etab = await getEtab(env, idEtablissement);
    if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');
    const terminaux = await getTerm(env, idEtablissement);
    const dejaEnregistre = terminaux.find(t => t.statut === 'actif' && t.idInstallationTerminal === idInstallationTerminal);
    if (dejaEnregistre) return ok({ idTerminal: dejaEnregistre.idTerminal, numeroTerminal: dejaEnregistre.numeroTerminal, jeton: dejaEnregistre.jeton });
    const numeroTerminal = prochainNumeroLibre(terminaux);
    if (!numeroTerminal) return fail(409, `Limite de ${MAX_TERMINAUX} terminaux atteinte pour cet établissement.`);
    const now = nowIso();
    const idTerminal = `${idEtablissement}-${numeroTerminal}`;
    const jeton = hex(24);
    terminaux.push({ idTerminal, idEtablissement, numeroTerminal, idInstallationTerminal, typeTerminal: body.typeTerminal || 'Inconnu', jeton, versionGAS: body.versionGAS || null, dateEnregistrement: now, derniereConnexion: now, derniereSynchronisation: null, statut: 'actif', verrouille: null });
    await putTerm(env, idEtablissement, terminaux);
    return ok({ idTerminal, numeroTerminal, jeton });
  },

  async 'heartbeat'(body, env) {
    const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
    const numeroTerminal = (body.numeroTerminal || '').trim();
    const idInstallationTerminal = (body.idInstallationTerminal || '').trim();
    const jeton = (body.jeton || '').trim();
    const typeTerminal = (body.typeTerminal || 'Inconnu').trim();
    if (!idEtablissement || !numeroTerminal || !jeton) return fail(400, 'Paramètres manquants.');
    const etab = await getEtab(env, idEtablissement);
    if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');
    const terminaux = await getTerm(env, idEtablissement);
    const idx = terminaux.findIndex(t => t.numeroTerminal === numeroTerminal);
    if (idx === -1) return fail(404, 'TERMINAL_INTROUVABLE');
    const t = terminaux[idx];
    if (t.statut !== 'actif') return fail(403, 'TERMINAL_DESACTIVE');
    if (t.verrouille && dansLeFutur(t.verrouille.dateFinBlocage)) {
      return json(423, { ok: false, dateFinBlocage: t.verrouille.dateFinBlocage, message: t.verrouille.message || 'Terminal temporairement verrouillé.' });
    }
    if (t.jeton !== jeton) {
      if (t.ancienJetonRevoque && jeton === t.ancienJetonRevoque && idInstallationTerminal === t.idInstallationTerminal) {
        terminaux[idx] = { ...t, ancienJetonRevoque: null, typeTerminal, derniereConnexion: nowIso() };
        await putTerm(env, idEtablissement, terminaux);
        return ok({ statut: 'actif', jetonRenouvele: t.jeton });
      }
      if (t.ancienJetonRevoque && jeton === t.ancienJetonRevoque) return fail(403, 'TERMINAL_DESACTIVE');
      return fail(401, 'JETON_INVALIDE');
    }
    if (t.idInstallationTerminal !== idInstallationTerminal) {
      const dateDebutBlocage = nowIso();
      const dateFinBlocage = new Date(Date.now() + LOCKOUT_HEURES * 3600 * 1000).toISOString();
      const message = `Un même identifiant terminal (${t.idTerminal}) est utilisé par deux appareils différents. Verrouillage ${LOCKOUT_HEURES}h.`;
      terminaux[idx] = { ...t, verrouille: { dateDebutBlocage, dateFinBlocage, message, installationA: t.idInstallationTerminal, installationB: idInstallationTerminal, typeTerminalA: t.typeTerminal || 'Inconnu', typeTerminalB: typeTerminal } };
      await putTerm(env, idEtablissement, terminaux);
      return json(423, { ok: false, dateFinBlocage, message });
    }
    terminaux[idx] = { ...t, typeTerminal, derniereConnexion: nowIso() };
    await putTerm(env, idEtablissement, terminaux);
    return ok({ statut: 'actif' });
  },

  async 'terminaux-status'(body, env) {
    const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
    if (!idEtablissement) return fail(400, 'ID établissement manquant.');
    const etab = await getEtab(env, idEtablissement);
    if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');
    const masquer = id => !id ? null : (id.length <= 6 ? id : `…${id.slice(-6)}`);
    const terminaux = await getTerm(env, idEtablissement);
    const publics = terminaux.sort((a, b) => a.numeroTerminal.localeCompare(b.numeroTerminal)).map(t => ({
      idTerminal: t.idTerminal, numeroTerminal: t.numeroTerminal, typeTerminal: t.typeTerminal || 'Inconnu',
      statut: t.statut, versionGAS: t.versionGAS, dateEnregistrement: t.dateEnregistrement,
      derniereConnexion: t.derniereConnexion, derniereSynchronisation: t.derniereSynchronisation,
      installation: masquer(t.idInstallationTerminal),
      verrouille: t.verrouille ? { dateDebutBlocage: t.verrouille.dateDebutBlocage, dateFinBlocage: t.verrouille.dateFinBlocage, message: t.verrouille.message, typeTerminalA: t.verrouille.typeTerminalA || 'Inconnu', typeTerminalB: t.verrouille.typeTerminalB || 'Inconnu', installationA: masquer(t.verrouille.installationA), installationB: masquer(t.verrouille.installationB) } : null
    }));
    return ok({ idEtablissement, terminaux: publics });
  },

  async 'licence-check'(body, env) {
    const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
    if (!idEtablissement) return fail(400, 'ID établissement manquant.');
    const etab = await getEtab(env, idEtablissement);
    if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');
    const { statut, joursRestants } = computeLicenceServeur(etab);
    return ok({ idEtablissement, statut, joursRestants, dateFinEssai: etab.dateFinEssai || null, dateActivation: etab.dateActivation || null });
  },

  async 'licence-activate'(body, env) {
    const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
    const cle = (body.cle || '').trim();
    if (!idEtablissement) return fail(400, 'ID établissement manquant.');
    if (!cle) return fail(400, 'Clé de licence manquante.');
    const etab = await getEtab(env, idEtablissement);
    if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');

    const PERMANENT_KEY = env.GAS_PERMANENT_KEY || 'dino2910';
    const LICENSE_SECRET = env.GAS_LICENSE_SECRET || '';
    const LIC_ANNUAL = 'GAS1804-HAITI2004';
    const LIC_TRIAL = 'GAS-TRIAL1804';
    const SECURE_RE = /^GAS-LIC-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}$/;
    const legacyKeys = (env.GAS_LEGACY_KEYS || '').split(/[\n,]/).map(s => s.trim().toUpperCase()).filter(Boolean);
    const cleU = cle.toUpperCase();

    async function genererCleAttendue(annee) {
      const h = (await hmacHex(LICENSE_SECRET, `${idEtablissement}|${annee}`)).slice(0, 12);
      return `GAS-LIC-${h.slice(0, 4)}-${h.slice(4, 8)}-${h.slice(8, 12)}`;
    }

    let type = null;
    if (cle === PERMANENT_KEY) type = 'permanent';
    else if (cleU === LIC_TRIAL) type = 'trial';
    else if (SECURE_RE.test(cleU) && LICENSE_SECRET) {
      const now = new Date().getFullYear();
      if (cleU === await genererCleAttendue(now) || cleU === await genererCleAttendue(now - 1)) type = 'secure';
    } else if (cleU === LIC_ANNUAL || legacyKeys.includes(cleU)) type = 'legacy';

    if (!type) return fail(401, 'CLE_INVALIDE');

    const now = nowIso();
    if (type === 'permanent') { etab.statutLicence = 'PERMANENTE'; etab.dateActivation = now; }
    else if (type === 'secure' || type === 'legacy') { etab.statutLicence = 'ACTIVE'; etab.dateActivation = now; }
    etab.dernierTypeCleValidee = type;
    await putEtab(env, idEtablissement, etab);

    const { statut, joursRestants } = computeLicenceServeur(etab);
    return ok({ idEtablissement, type, statut, joursRestants });
  },

  async 'licence-generate-key'(body, env) {
    const ADMIN_KEY = env.GAS_ADMIN_KEY || '';
    const LICENSE_SECRET = env.GAS_LICENSE_SECRET || '';
    if (!ADMIN_KEY || body.adminKey !== ADMIN_KEY) return fail(401, 'Clé administrateur invalide ou non configurée.');
    if (!LICENSE_SECRET) return fail(503, 'GAS_LICENSE_SECRET non configuré (wrangler secret put GAS_LICENSE_SECRET).');
    const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
    if (!idEtablissement) return fail(400, 'ID établissement manquant.');
    const annee = parseInt(body.annee, 10) || new Date().getFullYear();
    const h = (await hmacHex(LICENSE_SECRET, `${idEtablissement}|${annee}`)).slice(0, 12);
    const cle = `GAS-LIC-${h.slice(0, 4)}-${h.slice(4, 8)}-${h.slice(8, 12)}`;
    return ok({ idEtablissement, annee, cle });
  },

  async 'sync-push'(body, env) {
    const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
    const idTerminal = (body.idTerminal || '').trim();
    const operations = Array.isArray(body.operations) ? body.operations : [];
    if (!idEtablissement) return fail(400, 'ID établissement manquant.');
    if (!idTerminal) return fail(400, 'ID terminal manquant.');
    if (!operations.length) return ok({ count: 0 });
    if (operations.length > MAX_OPERATIONS_PAR_APPEL) return fail(413, `Trop d'opérations en un seul envoi (max ${MAX_OPERATIONS_PAR_APPEL}).`);
    const etab = await getEtab(env, idEtablissement);
    if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');
    let ecrites = 0;
    for (const op of operations) {
      if (!op || !op.idOperation || op.idEtablissement !== idEtablissement) continue;
      await env.GAS_KV.put(`syncops/${idEtablissement}/${op.idOperation}`, JSON.stringify(op));
      ecrites++;
    }
    return ok({ count: ecrites });
  },

  async 'sync-pull'(body, env) {
    const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
    const idTerminal = (body.idTerminal || '').trim();
    const depuis = body.depuis ? new Date(body.depuis).getTime() : 0;
    if (!idEtablissement) return fail(400, 'ID établissement manquant.');
    const etab = await getEtab(env, idEtablissement);
    if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');
    const list = await env.GAS_KV.list({ prefix: `syncops/${idEtablissement}/` });
    const toutes = await Promise.all(list.keys.map(k => env.GAS_KV.get(k.name).then(v => v ? JSON.parse(v) : null)));
    const operations = toutes.filter(Boolean)
      .filter(op => op.idTerminal !== idTerminal)
      .filter(op => new Date(op.dateHeure).getTime() > depuis)
      .sort((a, b) => a.dateHeure.localeCompare(b.dateHeure))
      .slice(0, MAX_OPERATIONS_RETOURNEES);
    return ok({ operations });
  },

  async 'resolve-conflict'(body, env) {
    const ADMIN_KEY = env.GAS_ADMIN_KEY || '';
    if (!ADMIN_KEY || body.adminKey !== ADMIN_KEY) return fail(401, 'Clé administrateur invalide ou non configurée.');
    const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
    const numeroTerminal = (body.numeroTerminal || '').trim();
    const decision = body.decision;
    if (!idEtablissement || !numeroTerminal) return fail(400, 'Paramètres manquants.');
    if (decision !== 'A' && decision !== 'B') return fail(400, 'decision doit être "A" ou "B".');
    const terminaux = await getTerm(env, idEtablissement);
    const idx = terminaux.findIndex(t => t.numeroTerminal === numeroTerminal);
    if (idx === -1) return fail(404, 'TERMINAL_INTROUVABLE');
    const t = terminaux[idx];
    if (!t.verrouille) return fail(409, "Ce terminal ne fait l'objet d'aucun conflit en cours.");
    const installationConservee = decision === 'A' ? t.verrouille.installationA : t.verrouille.installationB;
    const typeTerminalConserve = decision === 'A' ? (t.verrouille.typeTerminalA || t.typeTerminal || 'Inconnu') : (t.verrouille.typeTerminalB || 'Inconnu');
    const nouveauJeton = hex(24);
    terminaux[idx] = {
      ...t, idInstallationTerminal: installationConservee, typeTerminal: typeTerminalConserve,
      jeton: nouveauJeton, ancienJetonRevoque: t.jeton, verrouille: null,
      derniereConnexion: nowIso(),
      historiqueConflit: [...(t.historiqueConflit || []), { date: nowIso(), decision, installationConservee, installationDesactivee: decision === 'A' ? t.verrouille.installationB : t.verrouille.installationA }]
    };
    await putTerm(env, idEtablissement, terminaux);
    return ok({ idTerminal: t.idTerminal, installationConservee, jeton: nouveauJeton });
  }
};

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return json(204, {});
    const url = new URL(request.url);
    const m = url.pathname.match(/^\/api\/([a-z-]+)$/);
    if (!m) return fail(404, 'Route inconnue.');
    const fn = ROUTES[m[1]];
    if (!fn) return fail(404, 'Fonction inconnue.');
    if (request.method !== 'POST') return fail(405, 'Méthode non autorisée');
    let body = {};
    try { body = await request.json(); } catch (e) { /* corps vide toléré */ }
    try { return await fn(body, env); }
    catch (e) { return fail(500, 'Erreur serveur : ' + e.message); }
  }
};
