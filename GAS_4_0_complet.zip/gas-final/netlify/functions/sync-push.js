'use strict';
/* GAS 4.0 — §30-31 / §58 : réception des opérations d'un terminal.
   Chaque opération est stockée individuellement (clé = idOperation) sous
   syncops/{idEtablissement}/ pour permettre à sync-pull de les relister
   et de filtrer par date sans jamais réécrire un gros fichier unique. */

const { ok, fail, handleOptions, parseBody, store, getEtablissement } = require('./lib/store');

const MAX_OPERATIONS_PAR_APPEL = 500;

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
  const idTerminal = (body.idTerminal || '').trim();
  const operations = Array.isArray(body.operations) ? body.operations : [];

  if (!idEtablissement) return fail(400, 'ID établissement manquant.');
  if (!idTerminal) return fail(400, 'ID terminal manquant.');
  if (!operations.length) return ok({ count: 0 });
  if (operations.length > MAX_OPERATIONS_PAR_APPEL) {
    return fail(413, `Trop d'opérations en un seul envoi (max ${MAX_OPERATIONS_PAR_APPEL}).`);
  }

  const etab = await getEtablissement(idEtablissement);
  if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');

  const st = store();
  let ecrites = 0;
  for (const op of operations) {
    if (!op || !op.idOperation || op.idEtablissement !== idEtablissement) continue;
    await st.setJSON(`syncops/${idEtablissement}/${op.idOperation}`, op);
    ecrites++;
  }

  return ok({ count: ecrites });
};
