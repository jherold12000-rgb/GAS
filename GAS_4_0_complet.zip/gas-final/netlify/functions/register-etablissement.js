'use strict';
/* GAS 4.0 — §8 : option NOUVEAU. Crée l'ID établissement permanent et
   enregistre automatiquement le premier terminal sous le numéro -001
   (le suffixe n'est jamais choisi par l'utilisateur, §8).

   Mode local d'abord (configuration facilitée) : l'application peut
   fonctionner un moment sans serveur, avec un ID généré localement (voir
   creerNouvelEtablissementLocal côté client). Quand l'utilisateur se
   connecte enfin à un serveur, cette même fonction est rappelée avec :
   - idEtablissementSouhaite : l'ID déjà généré localement, à conserver
     si possible plutôt que d'en attribuer un nouveau (continuité) ;
   - dateDebutEssaiSouhaitee : la date réelle de première installation,
     pour que les 60 jours d'essai ne redémarrent pas à zéro simplement
     parce que la connexion arrive tardivement. */

const {
  ok, fail, handleOptions, parseBody, hex,
  genererIdEtablissementUnique, getEtablissement, putEtablissement, putTerminaux, nowIso,
  TRIAL_DAYS
} = require('./lib/store');

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  const nom = (body.nom || '').trim();
  const idInstallationTerminal = (body.idInstallationTerminal || '').trim();

  if (!nom) return fail(400, 'Le nom de l\'établissement est obligatoire.');
  if (!idInstallationTerminal) return fail(400, 'Identité d\'installation manquante.');

  /* Continuité d'un établissement d'abord créé en local : on garde son ID
     s'il est fourni et encore libre, sinon on retombe sur la génération
     normale (cas le plus courant : première connexion directe). */
  const idSouhaite = (body.idEtablissementSouhaite || '').trim().toUpperCase();
  let idEtablissement;
  if (idSouhaite && !(await getEtablissement(idSouhaite))) {
    idEtablissement = idSouhaite;
  } else {
    idEtablissement = await genererIdEtablissementUnique(body.sigle, nom);
  }

  const now = nowIso();
  /* §23 : période d'essai de 60 jours. Si l'établissement existait déjà
     localement avant cette connexion, on part de sa date réelle de
     création plutôt que de "maintenant" — plafonnée pour éviter une date
     fabriquée trop ancienne. */
  let dateDebutEssai = now;
  const dateSouhaitee = body.dateDebutEssaiSouhaitee ? new Date(body.dateDebutEssaiSouhaitee) : null;
  if (dateSouhaitee && !isNaN(dateSouhaitee.getTime()) && dateSouhaitee.getTime() <= Date.now()) {
    const plusAncienneAcceptee = Date.now() - TRIAL_DAYS * 86400000;
    dateDebutEssai = new Date(Math.max(dateSouhaitee.getTime(), plusAncienneAcceptee)).toISOString();
  }
  const dateFinEssai = new Date(new Date(dateDebutEssai).getTime() + TRIAL_DAYS * 86400000).toISOString();

  await putEtablissement(idEtablissement, {
    idEtablissement,
    nom,
    sigle: (body.sigle || '').trim(),
    commune: (body.commune || '').trim(),
    departement: (body.departement || '').trim(),
    telephone: (body.telephone || '').trim(),
    dateCreation: now,
    dateDebutEssai,
    dateFinEssai,
    versionGAS: body.versionGAS || null,
    statutLicence: 'ESSAI',
    dateActivation: null
  });

  const numeroTerminal = '001';
  const idTerminal = `${idEtablissement}-${numeroTerminal}`;
  const jeton = hex(24);

  await putTerminaux(idEtablissement, [{
    idTerminal, idEtablissement, numeroTerminal,
    idInstallationTerminal, typeTerminal: body.typeTerminal || 'Inconnu',
    jeton, versionGAS: body.versionGAS || null,
    dateEnregistrement: now, derniereConnexion: now, derniereSynchronisation: null,
    statut: 'actif', verrouille: null
  }]);

  return ok({ idEtablissement, idTerminal, numeroTerminal, jeton });
};
