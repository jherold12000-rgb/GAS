'use strict';
/* GAS 4.0 — §14-§17 : vérification périodique côté serveur.
   - Rejette un jeton inconnu (401).
   - Si le terminal est déjà verrouillé suite à un doublon, renvoie 423
     jusqu'à la fin du blocage de 48 heures, à tous les appelants,
     y compris le détenteur légitime (le verrouillage protège les
     données, §17, et attend une décision de l'administrateur, §18).
   - Si un même jeton valide est présenté par une installation physique
     différente de celle enregistrée (identifiant cloné sur un second
     appareil, §14), déclenche le doublon : verrouille le terminal
     48 heures et journalise les deux installations concernées (§16-§17).
   - Sinon, met à jour la dernière connexion et renvoie 200. */

const {
  ok, fail, json, handleOptions, parseBody,
  getEtablissement, getTerminaux, putTerminaux,
  nowIso, dansLeFutur, LOCKOUT_HEURES
} = require('./lib/store');

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
  const numeroTerminal = (body.numeroTerminal || '').trim();
  const idInstallationTerminal = (body.idInstallationTerminal || '').trim();
  const jeton = (body.jeton || '').trim();
  const typeTerminal = (body.typeTerminal || 'Inconnu').trim();

  if (!idEtablissement || !numeroTerminal || !jeton) {
    return fail(400, 'Paramètres manquants.');
  }

  const etab = await getEtablissement(idEtablissement);
  if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');

  const terminaux = await getTerminaux(idEtablissement);
  const idx = terminaux.findIndex(t => t.numeroTerminal === numeroTerminal);
  if (idx === -1) return fail(404, 'TERMINAL_INTROUVABLE');
  const t = terminaux[idx];

  if (t.statut !== 'actif') return fail(403, 'TERMINAL_DESACTIVE');

  /* Verrouillage déjà actif : bloque tout le monde jusqu'à l'échéance,
     y compris l'appelant légitime (§17). */
  if (t.verrouille && dansLeFutur(t.verrouille.dateFinBlocage)) {
    return json(423, {
      ok: false,
      dateFinBlocage: t.verrouille.dateFinBlocage,
      message: t.verrouille.message
        || 'Un même identifiant terminal est utilisé par deux appareils différents. '
          + 'Pour protéger les données de l\'établissement, ce terminal est temporairement verrouillé.'
    });
  }

  if (t.jeton !== jeton) {
    /* §18-19 : redistribution automatique après résolution d'un conflit.
       L'appareil conservé continue d'appeler heartbeat avec l'ancien
       jeton (partagé, maintenant révoqué) tant qu'il n'a pas reçu le
       nouveau — on le reconnaît ici à son installation, identique à celle
       enregistrée comme légitime par resolve-conflict, et on lui renvoie
       le jeton actuel sans ressaisie manuelle. */
    if (t.ancienJetonRevoque && jeton === t.ancienJetonRevoque
        && idInstallationTerminal === t.idInstallationTerminal) {
      terminaux[idx] = { ...t, ancienJetonRevoque: null, typeTerminal, derniereConnexion: nowIso() };
      await putTerminaux(idEtablissement, terminaux);
      return ok({ statut: 'actif', jetonRenouvele: t.jeton });
    }
    /* Même ancien jeton mais installation différente : c'est l'appareil
       désactivé par la résolution du conflit. Refus définitif, sans
       déclencher un nouveau verrouillage de doublon (§19). */
    if (t.ancienJetonRevoque && jeton === t.ancienJetonRevoque) {
      return fail(403, 'TERMINAL_DESACTIVE');
    }
    /* Jeton invalide et différent de celui enregistré : ce n'est pas le
       scénario de doublon (§14, même jeton cloné) mais une tentative
       non autorisée. On refuse sans verrouiller (ne pas permettre un
       déni de service en envoyant un jeton au hasard). */
    return fail(401, 'JETON_INVALIDE');
  }

  if (t.idInstallationTerminal !== idInstallationTerminal) {
    /* §14-§17 : même jeton, installation physique différente → doublon
       confirmé. Verrouille les deux appareils pendant 48 heures sans
       jamais supprimer de données (§17). Le type d'appareil de chaque
       côté est mémorisé pour que l'administrateur puisse identifier les
       deux terminaux à l'écran (§18 : « Type : Téléphone / Ordinateur »). */
    const dateDebutBlocage = nowIso();
    const dateFinBlocage = new Date(Date.now() + LOCKOUT_HEURES * 3600 * 1000).toISOString();
    const message = `Un même identifiant terminal (${t.idTerminal}) est utilisé par deux appareils `
      + `différents. Pour protéger les données de l'établissement, les deux terminaux sont `
      + `temporairement verrouillés pendant ${LOCKOUT_HEURES} heures. Un administrateur doit choisir `
      + `quel appareil conserver.`;
    terminaux[idx] = {
      ...t,
      verrouille: {
        dateDebutBlocage, dateFinBlocage, message,
        installationA: t.idInstallationTerminal,
        installationB: idInstallationTerminal,
        typeTerminalA: t.typeTerminal || 'Inconnu',
        typeTerminalB: typeTerminal
      }
    };
    await putTerminaux(idEtablissement, terminaux);
    return json(423, { ok: false, dateFinBlocage, message });
  }

  terminaux[idx] = { ...t, typeTerminal, derniereConnexion: nowIso() };
  await putTerminaux(idEtablissement, terminaux);
  return ok({ statut: 'actif' });
};
