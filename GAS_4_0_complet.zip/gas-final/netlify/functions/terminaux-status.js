'use strict';
/* GAS 4.0 — §21 : état des terminaux d'un établissement, tel que connu
   par le serveur (l'autorité, §15), pour alimenter le panneau
   d'administration « Terminaux » (afficher/désactiver/remplacer/détecter
   les doublons/résoudre les conflits). Ne renvoie jamais de jeton ni
   l'identité complète d'installation : uniquement des informations
   d'affichage et les 6 derniers caractères de chaque identité, suffisants
   pour distinguer deux appareils à l'écran sans exposer de secret
   réutilisable. */

const { ok, fail, handleOptions, parseBody, getEtablissement, getTerminaux } = require('./lib/store');

function masquer(id) {
  if (!id) return null;
  return id.length <= 6 ? id : `…${id.slice(-6)}`;
}

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
  if (!idEtablissement) return fail(400, 'ID établissement manquant.');

  const etab = await getEtablissement(idEtablissement);
  if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');

  const terminaux = await getTerminaux(idEtablissement);

  const publics = terminaux
    .sort((a, b) => a.numeroTerminal.localeCompare(b.numeroTerminal))
    .map(t => ({
      idTerminal: t.idTerminal,
      numeroTerminal: t.numeroTerminal,
      typeTerminal: t.typeTerminal || 'Inconnu',
      statut: t.statut,
      versionGAS: t.versionGAS,
      dateEnregistrement: t.dateEnregistrement,
      derniereConnexion: t.derniereConnexion,
      derniereSynchronisation: t.derniereSynchronisation,
      installation: masquer(t.idInstallationTerminal),
      verrouille: t.verrouille ? {
        dateDebutBlocage: t.verrouille.dateDebutBlocage,
        dateFinBlocage: t.verrouille.dateFinBlocage,
        message: t.verrouille.message,
        typeTerminalA: t.verrouille.typeTerminalA || 'Inconnu',
        typeTerminalB: t.verrouille.typeTerminalB || 'Inconnu',
        installationA: masquer(t.verrouille.installationA),
        installationB: masquer(t.verrouille.installationB)
      } : null
    }));

  return ok({ idEtablissement, terminaux: publics });
};
