'use strict';
/* GAS 4.0 — §18-19 : résolution d'un doublon par l'administrateur.
   Détermine quelle installation conserve le terminal, désactive l'autre,
   révoque l'ancien jeton (compromis puisque partagé par les deux
   appareils) et lève le verrouillage. Ne fait AUCUNE suppression de
   données (§17, §19).

   Non encore appelée par l'interface cliente de GAS_4_0_Phase6.html —
   l'écran de verrouillage (afficherEcranVerrouillage) invite déjà
   l'utilisateur à contacter l'administrateur ; un panneau d'administration
   pourra appeler cette fonction avec la clé ADMIN_KEY pour compléter le
   flux du §18 (choix « Conserver A / Conserver B »). */

const {
  ok, fail, handleOptions, parseBody, hex,
  getTerminaux, putTerminaux, nowIso
} = require('./lib/store');

/* Clé administrateur pour les opérations serveur sensibles. À définir
   comme variable d'environnement Netlify (Site settings → Environment
   variables → ADMIN_KEY). Aucune valeur par défaut n'est fournie ici :
   si elle n'est pas configurée, cette fonction refuse toute demande. */
const ADMIN_KEY = process.env.GAS_ADMIN_KEY || '';

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  if (!ADMIN_KEY || body.adminKey !== ADMIN_KEY) {
    return fail(401, 'Clé administrateur invalide ou non configurée côté serveur.');
  }

  const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
  const numeroTerminal = (body.numeroTerminal || '').trim();
  const decision = body.decision; /* 'A' ou 'B' — voir installationA/installationB du verrouillage */

  if (!idEtablissement || !numeroTerminal) return fail(400, 'Paramètres manquants.');
  if (decision !== 'A' && decision !== 'B') return fail(400, 'decision doit être "A" ou "B".');

  const terminaux = await getTerminaux(idEtablissement);
  const idx = terminaux.findIndex(t => t.numeroTerminal === numeroTerminal);
  if (idx === -1) return fail(404, 'TERMINAL_INTROUVABLE');
  const t = terminaux[idx];

  if (!t.verrouille) return fail(409, 'Ce terminal ne fait l\'objet d\'aucun conflit en cours.');

  const installationConservee = decision === 'A' ? t.verrouille.installationA : t.verrouille.installationB;
  const typeTerminalConserve = decision === 'A'
    ? (t.verrouille.typeTerminalA || t.typeTerminal || 'Inconnu')
    : (t.verrouille.typeTerminalB || 'Inconnu');
  const nouveauJeton = hex(24); /* révoque l'ancien jeton, partagé par les deux appareils */

  terminaux[idx] = {
    ...t,
    idInstallationTerminal: installationConservee,
    typeTerminal: typeTerminalConserve,
    jeton: nouveauJeton,
    /* Ancien jeton mémorisé temporairement : permet à heartbeat.js de
       reconnaître automatiquement l'appareil légitime (même installation
       que installationConservee, encore muni de l'ancien jeton partagé) et
       de lui redistribuer nouveauJeton sans ressaisie manuelle. L'appareil
       désactivé, lui, présente aussi l'ancien jeton mais une installation
       différente : heartbeat.js le renvoie TERMINAL_DESACTIVE (403) sans
       jamais lui donner le nouveau jeton. Purgé dès la première
       redistribution réussie (voir heartbeat.js). */
    ancienJetonRevoque: t.jeton,
    verrouille: null,
    dateEnregistrement: t.dateEnregistrement,
    derniereConnexion: nowIso(),
    historiqueConflit: [...(t.historiqueConflit || []), {
      date: nowIso(),
      decision,
      installationConservee,
      installationDesactivee: decision === 'A' ? t.verrouille.installationB : t.verrouille.installationA
    }]
  };
  await putTerminaux(idEtablissement, terminaux);

  return ok({
    idTerminal: t.idTerminal,
    installationConservee,
    /* Redistribué automatiquement à l'appareil conservé dès son prochain
       heartbeat (voir heartbeat.js) ; renvoyé aussi ici pour un panneau
       d'administration qui voudrait l'afficher/le journaliser. */
    jeton: nouveauJeton
  });
};
