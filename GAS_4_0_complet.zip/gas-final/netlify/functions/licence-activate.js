'use strict';
/* GAS 4.0 — §28-29, §59, §79 : valide une clé d'activation côté serveur.

   CORRECTIF DE SÉCURITÉ (faille héritée de GAS 3.0) : l'ancien format de
   renouvellement (GASxxH-SIGLE-CODE-NNNN) était généré côté client par
   une fonction purement déterministe, sans aucun secret — n'importe qui
   connaissant l'algorithme (visible dans le code source de l'app) pouvait
   fabriquer une clé "valide" pour n'importe quel établissement, sans
   payer ni contacter le fournisseur. Ce format n'est donc plus reconnu
   ici comme automatiquement valide.

   Trois catégories de clés sont désormais acceptées :
   1. Clé permanente administrateur (fixe, §29) — inchangée.
   2. Clé sécurisée "GAS-LIC-XXXX-XXXX-XXXX" — vérifiée par recalcul
      HMAC-SHA256 avec un secret qui ne quitte jamais le serveur
      (GAS_LICENSE_SECRET). Seule licence-generate-key.js (protégée par
      la clé administrateur) peut produire une clé qui passera cette
      vérification : c'est le mécanisme normal pour toute nouvelle
      activation ou tout renouvellement à partir de maintenant.
   3. Clés historiques (annuelle fixe + anciens renouvellements) déjà
      distribuées à de vraies écoles AVANT ce correctif : acceptées
      uniquement si elles figurent explicitement dans la liste d'exception
      GAS_LEGACY_KEYS (à renseigner une fois, par le fournisseur, à partir
      de ses propres registres de vente — pas par simple correspondance de
      format). Toute clé de cette forme qui n'est pas dans cette liste
      exacte est refusée, même si elle "ressemble" à une clé légitime :
      c'est précisément ce qui ferme la faille (la ressemblance de format
      ne suffit plus, seule une correspondance exacte avec une clé
      réellement émise compte). */

const {
  ok, fail, handleOptions, parseBody, hmacHex,
  getEtablissement, putEtablissement, nowIso, computeLicenceServeur
} = require('./lib/store');

const LIC_ANNUAL = 'GAS1804-HAITI2004';
const LIC_TRIAL = 'GAS-TRIAL1804';
const PERMANENT_KEY = process.env.GAS_PERMANENT_KEY || 'dino2910';
const LICENSE_SECRET = process.env.GAS_LICENSE_SECRET || '';
const SECURE_RE = /^GAS-LIC-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}$/;

/* Liste blanche exacte des clés historiques déjà distribuées avant ce
   correctif (une par ligne ou séparées par des virgules), à configurer
   ponctuellement par le fournisseur dans les variables d'environnement
   Netlify. Vide par défaut : aucune clé historique n'est acceptée tant
   que le fournisseur n'a pas explicitement renseigné celles à honorer. */
function listeCleHistoriques() {
  return (process.env.GAS_LEGACY_KEYS || '')
    .split(/[\n,]/).map(s => s.trim().toUpperCase()).filter(Boolean);
}

function genererCleAttendue(idEtablissement, annee) {
  const h = hmacHex(LICENSE_SECRET, `${idEtablissement}|${annee}`).slice(0, 12);
  return `GAS-LIC-${h.slice(0, 4)}-${h.slice(4, 8)}-${h.slice(8, 12)}`;
}

/* Vérifie une clé sécurisée en essayant l'année en cours puis l'année
   précédente (fenêtre de tolérance pour un renouvellement soumis juste
   après le changement d'année). */
function cleSecureValide(idEtablissement, cleU) {
  if (!LICENSE_SECRET) return false;
  const now = new Date().getFullYear();
  return cleU === genererCleAttendue(idEtablissement, now)
      || cleU === genererCleAttendue(idEtablissement, now - 1);
}

function classifierCle(idEtablissement, cleBrute) {
  const cle = (cleBrute || '').trim();
  if (cle === PERMANENT_KEY) return 'permanent';
  const cleU = cle.toUpperCase();
  if (cleU === LIC_TRIAL) return 'trial';
  if (SECURE_RE.test(cleU)) return cleSecureValide(idEtablissement, cleU) ? 'secure' : null;
  if (cleU === LIC_ANNUAL || listeCleHistoriques().includes(cleU)) return 'legacy';
  return null;
}

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
  const cle = body.cle || '';
  if (!idEtablissement) return fail(400, 'ID établissement manquant.');
  if (!cle) return fail(400, 'Clé de licence manquante.');

  const etab = await getEtablissement(idEtablissement);
  if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');

  const type = classifierCle(idEtablissement, cle);
  if (!type) return fail(401, 'CLE_INVALIDE');

  const now = nowIso();
  if (type === 'permanent') {
    etab.statutLicence = 'PERMANENTE';
    etab.dateActivation = now;
  } else if (type === 'secure' || type === 'legacy') {
    etab.statutLicence = 'ACTIVE';
    etab.dateActivation = now;
  }
  /* type === 'trial' : la période d'essai est déjà comptée depuis la
     création de l'établissement (§23) ; rien à changer côté statut. */
  etab.dernierTypeCleValidee = type;
  await putEtablissement(idEtablissement, etab);

  const { statut, joursRestants } = computeLicenceServeur(etab);
  return ok({ idEtablissement, type, statut, joursRestants });
};
