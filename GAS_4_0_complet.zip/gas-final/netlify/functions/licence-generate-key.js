'use strict';
/* GAS 4.0 — §28-29 : génération d'une clé de licence par le SERVEUR
   uniquement, à partir d'un secret jamais exposé côté client
   (GAS_LICENSE_SECRET). Remplace l'ancien mécanisme client
   (genLicenceRenewal côté navigateur) qui ne comportait aucun secret :
   n'importe qui connaissant le format pouvait fabriquer une clé valide
   pour n'importe quel établissement, sans autorisation du fournisseur.

   Protégée par la clé administrateur (GAS_ADMIN_KEY, la même que pour
   resolve-conflict.js) : seul le fournisseur, qui la détient, peut
   appeler cette fonction — typiquement depuis son propre poste
   (curl/Postman), après confirmation du paiement du renouvellement,
   jamais depuis l'application cliente elle-même. */

const { ok, fail, handleOptions, parseBody, hmacHex } = require('./lib/store');

const ADMIN_KEY = process.env.GAS_ADMIN_KEY || '';
const LICENSE_SECRET = process.env.GAS_LICENSE_SECRET || '';

/* Même dérivation que licence-activate.js : GAS-LIC-XXXX-XXXX-XXXX à
   partir de HMAC(secret, "idEtablissement|année"). */
function genererCle(idEtablissement, annee) {
  const h = hmacHex(LICENSE_SECRET, `${idEtablissement}|${annee}`).slice(0, 12);
  return `GAS-LIC-${h.slice(0, 4)}-${h.slice(4, 8)}-${h.slice(8, 12)}`;
}

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  if (!ADMIN_KEY || body.adminKey !== ADMIN_KEY) {
    return fail(401, 'Clé administrateur invalide ou non configurée côté serveur.');
  }
  if (!LICENSE_SECRET) {
    return fail(503, 'GAS_LICENSE_SECRET non configuré côté serveur (Site settings → Environment variables).');
  }

  const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
  if (!idEtablissement) return fail(400, 'ID établissement manquant.');
  const annee = parseInt(body.annee, 10) || new Date().getFullYear();

  return ok({ idEtablissement, annee, cle: genererCle(idEtablissement, annee) });
};
