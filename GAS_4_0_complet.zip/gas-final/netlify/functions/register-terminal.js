'use strict';
/* GAS 4.0 — §9-§11 : option EXISTANT. Rattache ce terminal à un
   établissement déjà créé et lui attribue automatiquement le prochain
   numéro libre (-002 ou -003). Refuse tout 4e terminal (§10, §72). */

const {
  ok, fail, handleOptions, parseBody, hex,
  getEtablissement, getTerminaux, putTerminaux,
  prochainNumeroLibre, nowIso, MAX_TERMINAUX
} = require('./lib/store');

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
  const idInstallationTerminal = (body.idInstallationTerminal || '').trim();

  if (!idEtablissement) return fail(400, 'ID établissement manquant.');
  if (!idInstallationTerminal) return fail(400, 'Identité d\'installation manquante.');

  const etab = await getEtablissement(idEtablissement);
  if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');

  const terminaux = await getTerminaux(idEtablissement);

  /* Idempotence : si cette installation possède déjà un terminal actif
     pour cet établissement (nouvel appel après un échec réseau côté
     client, par ex.), on renvoie le même terminal plutôt que d'en
     consommer un nouveau (§10 — ne pas gaspiller la limite de 3). */
  const dejaEnregistre = terminaux.find(
    t => t.statut === 'actif' && t.idInstallationTerminal === idInstallationTerminal
  );
  if (dejaEnregistre) {
    return ok({
      idTerminal: dejaEnregistre.idTerminal,
      numeroTerminal: dejaEnregistre.numeroTerminal,
      jeton: dejaEnregistre.jeton
    });
  }

  const numeroTerminal = prochainNumeroLibre(terminaux);
  if (!numeroTerminal) {
    return fail(409, `Limite de ${MAX_TERMINAUX} terminaux atteinte pour cet établissement (§10, §72).`);
  }

  const now = nowIso();
  const idTerminal = `${idEtablissement}-${numeroTerminal}`;
  const jeton = hex(24);

  terminaux.push({
    idTerminal, idEtablissement, numeroTerminal,
    idInstallationTerminal, typeTerminal: body.typeTerminal || 'Inconnu',
    jeton, versionGAS: body.versionGAS || null,
    dateEnregistrement: now, derniereConnexion: now, derniereSynchronisation: null,
    statut: 'actif', verrouille: null
  });
  await putTerminaux(idEtablissement, terminaux);

  return ok({ idTerminal, numeroTerminal, jeton });
};
