'use strict';
/* GAS 4.0 — §30-31 / §58 : renvoie à un terminal les opérations des
   AUTRES terminaux du même établissement, effectuées après `depuis`.
   La synchronisation ne franchit jamais la frontière d'un établissement
   (§58 : « limitée aux terminaux appartenant au même ID établissement »),
   ce qui est garanti ici par le préfixe syncops/{idEtablissement}/. */

const { ok, fail, handleOptions, parseBody, store, getEtablissement } = require('./lib/store');

const MAX_OPERATIONS_RETOURNEES = 500;

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
  const idTerminal = (body.idTerminal || '').trim();
  const depuis = body.depuis ? new Date(body.depuis).getTime() : 0;

  if (!idEtablissement) return fail(400, 'ID établissement manquant.');

  const etab = await getEtablissement(idEtablissement);
  if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');

  const st = store();
  const { blobs } = await st.list({ prefix: `syncops/${idEtablissement}/` });

  const toutes = await Promise.all(
    blobs.map(b => st.get(b.key, { type: 'json' }))
  );

  const operations = toutes
    .filter(Boolean)
    .filter(op => op.idTerminal !== idTerminal) /* jamais ses propres opérations en écho (§74) */
    .filter(op => new Date(op.dateHeure).getTime() > depuis)
    .sort((a, b) => a.dateHeure.localeCompare(b.dateHeure))
    .slice(0, MAX_OPERATIONS_RETOURNEES);

  return ok({ operations });
};
