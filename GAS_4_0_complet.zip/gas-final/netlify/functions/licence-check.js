'use strict';
/* GAS 4.0 — §22-§28, §79 : statut de licence calculé par le serveur, seule
   autorité pour la période d'essai et l'activation (le client ne fait que
   refléter ce résultat, jamais l'inverse). Appelée périodiquement par le
   client (au démarrage et à chaque heartbeat) pour rafraîchir le statut
   mis en cache localement, utilisé aussi hors connexion. */

const {
  ok, fail, handleOptions, parseBody,
  getEtablissement, computeLicenceServeur
} = require('./lib/store');

exports.handler = async (event) => {
  const pre = handleOptions(event);
  if (pre) return pre;
  if (event.httpMethod !== 'POST') return fail(405, 'Méthode non autorisée');

  const body = parseBody(event);
  const idEtablissement = (body.idEtablissement || '').trim().toUpperCase();
  if (!idEtablissement) return fail(400, 'ID établissement manquant.');

  const etab = await getEtablissement(idEtablissement);
  if (!etab) return fail(404, 'ETABLISSEMENT_INTROUVABLE');

  const { statut, joursRestants } = computeLicenceServeur(etab);

  return ok({
    idEtablissement,
    statut,
    joursRestants,
    dateFinEssai: etab.dateFinEssai || null,
    dateActivation: etab.dateActivation || null
  });
};
