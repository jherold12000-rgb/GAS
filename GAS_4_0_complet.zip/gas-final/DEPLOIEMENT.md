# Déploiement du serveur GAS

L'application (GAS_4_0.html) fonctionne seule, en mode local, sans aucun serveur.
Un serveur n'est nécessaire que pour : la synchronisation entre plusieurs
terminaux, la limite de 3 terminaux par établissement, et la validation de
licence à distance.

Trois façons de déployer ce serveur, au choix :

## 1. server/ — n'importe quel hébergeur Node (recommandé)

Fonctionne sur Render, Railway, Fly.io, un VPS, DigitalOcean App Platform,
Glitch, Replit, ou toute machine capable de lancer Node.

    cd server
    npm install
    npm start

Le serveur écoute sur le port défini par la variable PORT (8787 par défaut).
Une fois déployé, copier l'URL publique + "/api" dans l'application, écran
Paramètres > Serveur GAS. Exemple : https://mon-app.onrender.com/api

Variables d'environnement optionnelles : GAS_ADMIN_KEY, GAS_LICENSE_SECRET,
GAS_PERMANENT_KEY, GAS_DATA_DIR (dossier de stockage, par défaut ./data).

## 2. cloudflare/ — Cloudflare Workers

Pour un déploiement à l'échelle mondiale, sans gérer de serveur.

    cd cloudflare
    npm install -g wrangler
    wrangler kv namespace create GAS_KV
    # copier l'id retourné dans wrangler.toml
    wrangler secret put GAS_ADMIN_KEY
    wrangler secret put GAS_LICENSE_SECRET
    wrangler deploy

URL à saisir dans l'application : https://gas-server.votre-compte.workers.dev/api

## 3. netlify/ — Netlify (option historique, toujours fonctionnelle)

    Connecter le dépôt à Netlify, ou utiliser Netlify CLI.
    netlify.toml redirige déjà /api/* vers les fonctions Netlify.

URL à saisir dans l'application : https://votre-site.netlify.app/api

## Dans les trois cas

L'application appelle toujours le même chemin générique : {URL}/api/{fonction}.
Aucune des trois options n'exige de changement dans GAS_4_0.html — seule
l'adresse saisie dans Paramètres change.
