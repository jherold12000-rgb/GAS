# GAS 4.0 — Phase 6

## Contenu du paquet

```
GAS_4_0_Phase6.html   → l'application (fichier unique, ouvrir directement dans un navigateur)
manifest.json          → manifeste PWA (nom, icônes, couleur de thème)
sw.js                  → service worker (mise en cache de l'app shell pour le hors-ligne)
icons/                 → icônes dérivées du logo GAS, toutes les tailles requises + favicon.ico
```

## Utilisation

**Ouverture directe (le plus simple) :** double-cliquer sur `GAS_4_0_Phase6.html`.
L'application fonctionne normalement (IndexedDB, licence, données) sans les
autres fichiers du paquet ; ils ne sont utiles que pour un déploiement web.

**Déploiement web (recommandé pour profiter de l'icône d'installation et du
hors-ligne complet) :** déposer les 4 éléments (`GAS_4_0_Phase6.html`,
`manifest.json`, `sw.js`, `icons/`) à la racine du même dossier sur votre
hébergeur (Netlify, par exemple, comme pour les fonctions serveur déjà
utilisées par la licence et les terminaux). Le navigateur proposera alors
« Installer GAS » avec l'icône du logo, et l'app se rechargera même sans
réseau grâce au service worker.

## Icônes

Générées à partir du logo GAS fourni (emblème recadré, sans le texte, pour
rester lisible en petite taille) :
- `icon-48/72/96/128/144/152/192/512.png` — icônes standard
- `icon-maskable-192/512.png` — variante avec marge de sécurité et fond bleu
  GAS (#1a3a6b), pour Android « adaptive icons »
- `apple-touch-icon.png` (180×180) — icône iOS
- `favicon.ico` — favicon multi-résolution (16/32/48)

## Phase 6 — ce qui a été ajouté dans ce paquet

- Manifeste et icônes PWA complets (§76 point 46 « Optimisation PWA »),
  jusqu'ici absents (manifeste minimal sans icône).
- Service worker pour le fonctionnement hors-ligne de l'app shell elle-même
  (§4), en complément d'IndexedDB qui gère déjà les données hors ligne.
- Correction de sécurité (§59) : l'expiration de session était calculée
  mais jamais vérifiée ; une surveillance active déconnecte désormais
  l'utilisateur à l'expiration.
- Panneau « Diagnostic GAS 4.0 » dans Paramètres : 12 auto-tests non
  destructifs couvrant les points du §77 vérifiables sans second appareil.

Les tests du §77 nécessitant deux terminaux physiques réels (doublon
d'identifiant, réattribution -002/-003, synchronisation croisée réelle)
restent à vérifier manuellement, comme indiqué dans le panneau Diagnostic.

## Fonctions serveur (Netlify Functions + Blobs)

Le fichier HTML appelait déjà un serveur Netlify (`serverCall`, §15/§22/§28
du cahier des charges) pour l'identité établissement, les terminaux et la
synchronisation, mais aucune fonction serveur n'existait encore. Ce paquet
ajoute :

```
netlify.toml                          → configuration Netlify (dossier des fonctions)
package.json                          → dépendance @netlify/blobs
netlify/functions/lib/store.js        → bibliothèque partagée (stockage, IDs)
netlify/functions/register-etablissement.js  → §8  : NOUVEAU établissement + terminal -001
netlify/functions/register-terminal.js       → §9-11 : EXISTANT, attribution -002/-003, refus du 4e (§72)
netlify/functions/heartbeat.js               → §14-17 : détection de doublon, verrouillage 48h
netlify/functions/terminaux-status.js         → §21 : état des terminaux pour le panneau admin (sans secrets)
netlify/functions/sync-push.js               → §30-31/§58 : réception des opérations d'un terminal
netlify/functions/sync-pull.js               → §30-31/§58 : envoi des opérations des autres terminaux
netlify/functions/resolve-conflict.js        → §18-19 : résolution admin d'un doublon
```

**Déploiement :**

1. Déposer l'ensemble du dossier (HTML, `manifest.json`, `sw.js`, `icons/`,
   `netlify.toml`, `package.json`, `netlify/`) sur un dépôt Git connecté à
   Netlify, ou glisser-déposer le dossier sur app.netlify.com. Netlify
   installera automatiquement `@netlify/blobs` et déploiera les fonctions.
2. Netlify Blobs est activé automatiquement sur les sites Netlify : aucune
   configuration supplémentaire n'est nécessaire pour le stockage.
3. Une fois le site en ligne (ex. `https://mon-site.netlify.app`), ouvrir
   `GAS_4_0_Phase6.html`, chercher la ligne :
   ```js
   const GAS_SERVER_BASE='https://VOTRE-SITE.netlify.app';
   ```
   et remplacer par l'URL réelle du site déployé.
4. (Optionnel, pour la résolution administrateur des doublons, §18) Définir
   la variable d'environnement `GAS_ADMIN_KEY` dans Netlify (Site
   settings → Environment variables). Sans cette variable, la fonction
   `resolve-conflict` refuse toute requête.

**Ce qui est couvert :**

- Création d'un ID établissement permanent et unique (§5-§6, format
  `GAS-SIGLE-XXXXXX`) et du terminal -001 (§8).
- Rattachement automatique du 2e et 3e terminal, refus strict du 4e (§9-11,
  §72, testé : §77 tests 3 à 6).
- Détection serveur d'un identifiant terminal cloné sur un second appareil
  (même jeton, installation physique différente) et verrouillage des deux
  appareils pendant 48 heures sans suppression de données (§14-17, §77
  tests 8-9). Un heartbeat s'exécute désormais au démarrage **et** toutes
  les 10 minutes pendant la session (auparavant, seule la vérification au
  démarrage existait, ce qui aurait laissé un doublon actif indétecté
  pendant toute une session ouverte).
- Résolution du conflit par l'administrateur, avec révocation du jeton
  compromis (§18-19, §77 test 10). **Panneau intégré dans Paramètres >
  Terminaux > « État serveur des terminaux »** : affiche les terminaux
  connus du serveur, signale les doublons verrouillés avec le type de
  chaque appareil (ex. Ordinateur vs Mobile), et permet à l'administrateur
  de choisir quel appareil conserver après saisie de la clé serveur.
- Synchronisation multi-terminaux réelle entre les -001/-002/-003 d'un
  même établissement, strictement cloisonnée par ID établissement (§30-32,
  §58, §74, §77 test 15).
- Vérification du doublon désormais active pendant toute la session
  (heartbeat au démarrage puis toutes les 10 minutes), pas seulement au
  lancement de l'application.

**Ce qui a été ajouté dans cette mise à jour (corrige les deux points
« reste à faire » ci-dessus) :**

- **Redistribution automatique du jeton après résolution de conflit
  (§18-19).** `resolve-conflict.js` mémorise désormais l'ancien jeton
  révoqué. Au heartbeat suivant, l'appareil conservé (reconnu par son
  identité d'installation) reçoit automatiquement le nouveau jeton et le
  stocke sans aucune action manuelle ; l'appareil désactivé reçoit un
  refus définitif (403) sans redéclencher de verrouillage.
- **Contrôle serveur du statut de licence (§22-28, §79).**
  `register-etablissement.js` fixe désormais `dateDebutEssai` /
  `dateFinEssai` (60 jours, horloge serveur) dès la création de
  l'établissement. Deux nouvelles fonctions :
  - `licence-check.js` — renvoie le statut de licence calculé par le
    serveur (ESSAI / ESSAI_EXPIRANT / EXPIRE / ACTIVE / PERMANENTE),
    interrogée au démarrage et à chaque heartbeat, mise en cache
    localement pour l'usage hors-ligne.
  - `licence-activate.js` — enregistre côté serveur qu'une clé (clé
    annuelle fixe, renouvellement `GASxxH-SIGLE-CODE-NNNN`, ou clé
    permanente administrateur `dino2910`/`GAS_PERMANENT_KEY`) a été
    validée, sans changer le format des clés existantes ni créer un
    second système de licence (§2, §79).
  - Le client bloque désormais réellement l'accès (écran dédié, avec
    réactivation sur place) quand le serveur confirme l'expiration —
    jusqu'ici l'expiration n'était que signalée par une notification, sans
    blocage effectif. Ce blocage ne se déclenche jamais si le serveur n'a
    encore jamais pu être contacté pour cet établissement, pour préserver
    l'usage hors-ligne dès l'installation (§4/§75).

**Limite connue restante :** les clés annuelles/de renouvellement
(`GAS1804-HAITI2004`, format `GASxxH-...`) sont générées côté client
sans secret (n'importe qui connaissant le format peut en fabriquer une
valide pour n'importe quel établissement) — un défaut déjà présent dans
GAS 3.0, volontairement non modifié ici pour ne pas invalider des clés
déjà distribuées à des écoles réelles. Le § 28 du cahier des charges
recommande un secret serveur pour la génération des clés ; en discuter
avant de changer ce mécanisme, car cela casserait la compatibilité avec
les clés déjà en circulation.

---

**Correctif de sécurité (deuxième mise à jour) — faille héritée de
GAS 3.0, corrigée :**

Le format de renouvellement (`GASxxH-SIGLE-CODE-NNNN`) était généré
côté client par une fonction purement déterministe, **sans aucun
secret** — n'importe qui connaissant l'algorithme (visible dans le code
source de l'app) pouvait fabriquer une clé "valide" pour n'importe quel
établissement, sans payer ni contacter le fournisseur. Pire : les
fonctions « Renouveler » et « Auto-renouvellement » généraient ELLES-MÊMES
une telle clé et l'activaient instantanément en local, sans jamais
contacter le fournisseur ni même le serveur GAS — un renouvellement
illimité et gratuit en un clic, pour n'importe qui.

Ce qui a changé :
- `netlify/functions/licence-activate.js` ne reconnaît plus le format
  `GASxxH-...` par sa simple forme. Il n'accepte que : (1) la clé
  permanente administrateur, (2) un **nouveau format sécurisé**
  `GAS-LIC-XXXX-XXXX-XXXX`, vérifié par recalcul HMAC-SHA256 avec un
  secret qui ne quitte jamais le serveur (`GAS_LICENSE_SECRET`), (3) une
  clé figurant explicitement dans `GAS_LEGACY_KEYS` (liste blanche exacte
  à renseigner une fois par le fournisseur, à partir de ses propres
  registres de vente, pour les écoles qui ont déjà reçu une vraie clé
  avant ce correctif — la ressemblance de format ne suffit plus, seule une
  correspondance exacte compte).
- Nouvelle fonction `licence-generate-key.js`, protégée par la clé
  administrateur (`GAS_ADMIN_KEY`), qui produit une clé sécurisée pour un
  établissement donné. C'est l'unique façon légitime d'obtenir une clé de
  renouvellement désormais — à exécuter par le fournisseur lui-même
  (curl/Postman), jamais depuis l'application cliente.
- Les boutons « Renouveler », « Auto-renouvellement » et « Générer clé »
  côté client ne fabriquent plus de clé : ils composent une demande par
  email au fournisseur. La clé reçue en retour doit être saisie dans le
  champ « Activer une clé », où elle est désormais obligatoirement vérifiée
  par le serveur avant tout octroi (aucun octroi local silencieux possible
  pour les types `renewal`/`secure`, y compris hors ligne — la clé annuelle
  fixe et l'essai restent utilisables hors ligne comme avant).

**Configuration Netlify à faire par le fournisseur :**
- `GAS_LICENSE_SECRET` — chaîne secrète longue et aléatoire, à générer
  une fois et ne jamais divulguer. Indispensable pour que
  `licence-generate-key.js` et `licence-activate.js` fonctionnent.
- `GAS_LEGACY_KEYS` — optionnel, liste des clés déjà distribuées avant ce
  correctif que vous souhaitez continuer à honorer (une par ligne ou
  séparées par des virgules). Laisser vide si aucune clé historique à
  honorer.

**Limite résiduelle assumée :** la clé annuelle fixe unique
(`GAS1804-HAITI2004`, partagée entre tous les clients) n'a pas été
supprimée ni changée — la remplacer nécessite de réémettre une clé à
chaque établissement existant, une décision commerciale qui dépasse un
simple correctif de code. Le nouveau format sécurisé est recommandé pour
tout nouveau client ou renouvellement à partir de maintenant.

---

**Audit Phase 2 (§41-53) — administration :**

Constat : Parents, Inscriptions (workflow complet préinscription→matricule),
Transferts, Personnel (avec recherche par ID employé §46), Documents (GED)
et Courriers étaient déjà largement implémentés dans ce fichier avant
cette mise à jour (Phase 3 pédagogie également très avancée). Deux
manques réels identifiés et corrigés dans cette version :

1. **§53 Courriers entrant** : le module ne gérait que des courriers
   sortants générés à partir de modèles (aucune trace des courriers
   *reçus*, aucun numéro, aucun champ expéditeur/destinataire, aucune
   recherche). Ajouté : numérotation séquentielle `CR-AAAA-NNNN`,
   distinction entrant/sortant, formulaire dédié « Enregistrer un
   courrier entrant » (expéditeur, objet, pièce jointe scannée, statut
   traité/en attente), et une barre de recherche sur objet/numéro/
   expéditeur/destinataire.
2. **§41/§44 historique élève** : les transferts d'un élève étaient bien
   enregistrés (liés par `eleve_id`) mais n'apparaissaient nulle part sur
   sa fiche ni sur son rapport imprimable. Ajouté une section « Historique
   des transferts » dans le rapport individuel de l'élève
   (`genererRapportEleve`).
3. **§45 fiche Personnel** : il manquait sexe, service, email, adresse,
   qualification, spécialité et formation(s) suivie(s). Tous ajoutés au
   formulaire, à l'enregistrement et affichés (sexe/service) dans le
   tableau de liste.
4. **§49 conflits de salle** : la détection de conflit d'emploi du temps
   existait déjà pour les enseignants, mais pas pour les salles (deux
   classes affectées à la même salle au même créneau). Ajoutée en miroir
   de la détection enseignant existante.
5. **§55 alertes manquantes** : deux types d'alerte prévus par la liste du
   cahier des charges n'étaient pas générés. Ajoutés à `compilerAlertes()` :
   « enseignant sans affectation » (ni titulaire d'une classe, ni affecté
   à une matière) et « conflit de synchronisation à résoudre »
   (conflitsSync ouverts).

Audit Phase 4 (§54-57 pilotage) par ailleurs : tableau de bord,
corrélation présence/résultats, élèves/classes à risque et rapports
étaient déjà largement couverts avant cette session.

---

**Audit final (§56-60, sécurité et journal d'audit) :**

6. **§60 journal d'audit — ID terminal manquant** : le journal
   (`journalActivites`) enregistrait déjà utilisateur/date/heure/action/
   module/objet/anciennes-nouvelles valeurs/appareil, mais pas l'ID
   terminal. Ajouté (composé à partir de l'ID établissement + numéro de
   terminal enregistrés localement).
7. **§60 événements manquants** : « verrouillage », « déverrouillage »,
   « expiration » (licence) et « tentative de quatrième terminal »
   n'étaient pas explicitement journalisés (l'activation et le
   remplacement de terminal l'étaient déjà). Ajoutés aux points de code
   correspondants (`heartbeatServeur`, `licenceBloquante`,
   `rattacherTerminalExistant`).
8. **§57 numérotation des sauvegardes** : l'historique affichait déjà
   date/type/taille/statut mais pas de numéro séquentiel « Backup 001,
   002, 003... ». Ajouté (calculé par ordre chronologique).

**Vérifié conforme, rien à corriger** : expiration de session (§59, déjà
appliquée avec surveillance active), export CSV des rapports (§56, déjà
présent sur bilan financier/impayés/effectifs), structures IndexedDB
(§61-66, largement couvertes — quelques stores consolidés différemment du
libellé exact du cahier des charges, ce qui est explicitement autorisé
par le §61).

**Manques restants, non corrigés — nécessitent une décision ou un
travail dédié plus lourd, hors périmètre d'une correction ponctuelle :**
- **§77 tests d'acceptation** : les tests automatisables sont couverts
  par le panneau de diagnostic existant, mais certains (doublon réel sur
  deux appareils physiques, migration réelle depuis une base GAS 3.0)
  ne peuvent être vérifiés qu'en conditions réelles, pas dans cet
  environnement.

---

**Suite de l'audit — §49 salles, §56 formats Excel/Word :**

9. **§49/§61 fiche « salle » dédiée** : la salle n'était qu'un champ
   texte libre sur chaque créneau d'emploi du temps. Ajout d'un nouveau
   store `salles` (nom, type, capacité, équipement) avec un écran de
   gestion complet (🚪 « Gérer les salles », accessible depuis l'Emploi du
   temps). Le champ « Salle » du créneau propose désormais les salles
   enregistrées via une liste déroulante suggestive (`<datalist>`) tout en
   restant compatible avec la saisie libre existante.
10. **§56 formats Excel et Word** : seuls impression/PDF/CSV existaient.
    Ajout de deux fonctions génériques, en pur JavaScript et **sans
    bibliothèque externe** (pour préserver le fonctionnement hors-ligne,
    §4) :
    - `exportExcel(feuille, entêtes, lignes, fichier)` — génère un fichier
      SpreadsheetML (`.xls`), ouvert nativement par Excel/LibreOffice/
      Google Sheets.
    - `exportWord(titre, htmlCorps, fichier)` — génère un document HTML
      avec en-tête Office (`.doc`), ouvert nativement par Word en
      conservant tableaux et mise en forme.
    Câblés sur 4 rapports (boutons 📗 Excel / 📘 Word ajoutés à côté du
    CSV existant) : Impayés, Bilan financier, Rapport d'effectif,
    Tableau de pilotage. Le même mécanisme générique (`exportExcel`/
    `exportWord`, ou l'utilitaire `_tableToExcel`/`_tableToWord` qui lit
    directement un `<table>` déjà affiché) peut être appliqué à n'importe
    quel autre rapport en une ligne de code.

**Manques restants après cette passe :**
- Les autres rapports (rapport élève individuel, rapports enseignant/
  classe/matière/discipline/inscriptions/transferts/synchronisation/
  licence listés au §56) n'ont pas encore de bouton Excel/Word — le
  mécanisme générique existe, il reste à l'ajouter rapport par rapport.
- **§77 tests d'acceptation** : les tests automatisables sont couverts
  par le panneau de diagnostic existant, mais certains (doublon réel sur
  deux appareils physiques, migration réelle depuis une base GAS 3.0)
  ne peuvent être vérifiés qu'en conditions réelles, pas dans cet
  environnement.

---

**Suite du câblage Excel/Word (§56) :**

Boutons 📗 Excel / 📘 Word ajoutés sur 7 rapports supplémentaires :
Transferts, Discipline, Inscriptions, Enseignants, Classes, Terminaux
(panneau Paramètres), et Rapport élève individuel (celui-ci en Word
uniquement — document narratif multi-sections, moins adapté à un export
Excel tabulaire ; réutilise le même contenu déjà calculé pour
l'impression, sans dupliquer la logique).

**Manques restants, mineurs et à faible enjeu** : rapport matière (pas de
listing dédié — les matières vivent dans le module Programmes), rapport
de synchronisation et rapport de licence (données déjà consultables à
l'écran dans Paramètres, mais sans bouton d'export dédié). Le mécanisme
générique (`exportExcel`/`exportWord`/`_tableToExcel`/`_tableToWord`)
reste disponible pour les ajouter en une ligne si besoin.
- **§77 tests d'acceptation** : toujours hors de portée de cet
  environnement de développement (doublon réel sur deux appareils
  physiques, migration réelle depuis une base GAS 3.0).

---

**Dernière passe — clôture du §56 et vérification du §33 :**

Boutons 📗 Excel / 📘 Word ajoutés sur les 3 derniers rapports du §56 :
« Évolution par matière » (onglet Palmarès ▸ Évolution — moyennes par
matière et par période, c'est le contenu réel du « rapport matière »),
Historique des synchronisations, et Historique de licence (tous deux
dans Paramètres). **Le §56 est désormais couvert dans sa totalité** :
tous les rapports listés ont au moins impression + CSV, et la plupart ont
aussi Excel/Word.

**§33 vérifié conforme, rien à corriger** : la détection de conflit de
synchronisation (`appliquerOperationDistante`) s'applique uniformément à
tous les modules et exige toujours une résolution manuelle par
l'administrateur (jamais de fusion automatique silencieuse) — ce qui
satisfait, voire dépasse, l'exigence du cahier des charges de réserver
une « politique de résolution stricte » aux données sensibles (notes,
finances, inscriptions, transferts, discipline).

**Ce qui reste, définitivement hors de portée de cet environnement de
développement** : les tests du §77 nécessitant des conditions réelles
(doublon sur deux appareils physiques distincts, migration depuis une
vraie base de données GAS 3.0 existante) — à valider par le fournisseur
sur le terrain avant mise en production.

---

**Re-vérification complète demandée par l'utilisateur — Phase 3 pédagogie
(§34-40) et §51 discipline, plus corrections trouvées :**

Vérifié en détail et conforme, rien à changer :
- §34-36 Programme pédagogique (Domaine→Compétence→Thématique→Objectif→
  Notion) : module complet (`MODULES.programme`), arborescence éditable.
- §37 Banque d'exercices : les 15 types d'exercices du cahier des charges
  sont tous présents mot pour mot (QCM, Vrai/Faux, Association,
  Classement, Chronologie, Texte à trous, Correction, Remise en ordre,
  Transformation, Production courte, Résolution de problème, Analyse,
  Justification, Application, Réinvestissement).
- §38 Évaluations : élève, objectif, évaluation, note, date, période,
  enseignant — tous les champs requis sont bien enregistrés.
- §39-40 Progression et remédiation : statuts acquis/partiel/non-acquis
  calculés automatiquement à partir des évaluations ; les 3 actions de
  remédiation du cahier des charges (reprise de la notion, exercices de
  remédiation, nouvelle évaluation) sont bien celles proposées.
- §42 Parents : un parent peut bien être associé à plusieurs élèves
  (`enfants_ids[]`).
- §33 (revérifié) : résolution de conflit toujours manuelle, pour tous
  les modules sans exception.

Deux manques réels trouvés et corrigés :
1. **§37 filtres incomplets** : seuls Type et Difficulté étaient filtrables
   dans la banque d'exercices (Niveau/Matière n'étaient couverts que par
   une recherche texte approximative, Thématique/Objectif pas du tout).
   Ajouté : filtres dédiés Niveau, Matière, et Objectif/Thématique.
2. **§51 workflow disciplinaire incomplet** : le cahier des charges décrit
   Élève→Incident→Description→**Témoin**→**Mesure prise**→Sanction→
   **Communication parent**→**Suivi**→**Clôture**, mais seuls
   description/gravité/sanction existaient. Ajoutés : champ témoin(s),
   mesure prise (distincte de la sanction), communication parent
   (case à cocher + détail), statut de suivi (Ouvert/En suivi/Clôturé)
   affiché et modifiable ; les incidents sont maintenant aussi éditables
   (pas seulement supprimables). Exports Excel/Word mis à jour en
   conséquence.

**Statut global** : après cette re-vérification ciblée sur la Phase 3 et
la discipline, aucune autre section du cahier des charges n'a révélé de
manque supplémentaire. Les seuls points non couverts restent ceux déjà
documentés plus haut : §77 (tests nécessitant des conditions réelles) et
les quelques rapports mineurs sans export Excel/Word dédié.
