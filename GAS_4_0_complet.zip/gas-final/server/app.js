'use strict';
/* ─────────────────────────────────────────────────────────────────────────
   GAS 4.0 — Serveur générique (identité établissement, licence, terminaux,
   synchronisation).

   Ce serveur n'est lié à aucun hébergeur en particulier. Il fonctionne sur
   Render, Railway, Fly.io, un VPS, DigitalOcean App Platform, Glitch,
   Replit, ou tout autre hôte capable de lancer "node app.js" avec un
   disque persistant.

   Chaque fonction (register-etablissement.js, sync-push.js, etc.) garde
   exactement le même format que sous Netlify : un module qui exporte
   handler(event) et retourne {statusCode, headers, body}. Ce fichier ne
   fait que traduire les requêtes HTTP Express vers ce format, et
   inversement — aucune logique métier n'est dupliquée.

   Démarrage local :
     npm install
     npm start
   Le serveur écoute sur le port défini par la variable d'environnement
   PORT (par défaut 8787).

   URL à saisir dans les Paramètres de l'application GAS, une fois
   déployé : https://votre-domaine.exemple/api
   ───────────────────────────────────────────────────────────────────────── */

const express = require('express');
const path = require('path');

const FUNCTIONS = {
  'register-etablissement': require('./register-etablissement'),
  'register-terminal': require('./register-terminal'),
  'heartbeat': require('./heartbeat'),
  'terminaux-status': require('./terminaux-status'),
  'licence-check': require('./licence-check'),
  'licence-activate': require('./licence-activate'),
  'licence-generate-key': require('./licence-generate-key'),
  'sync-push': require('./sync-push'),
  'sync-pull': require('./sync-pull'),
  'resolve-conflict': require('./resolve-conflict')
};

const app = express();
app.use(express.text({ type: '*/*', limit: '5mb' }));

app.all('/api/:fn', async (req, res) => {
  const mod = FUNCTIONS[req.params.fn];
  if (!mod || typeof mod.handler !== 'function') {
    return res.status(404).json({ ok: false, message: 'Fonction inconnue.' });
  }
  const event = {
    httpMethod: req.method,
    headers: req.headers,
    body: typeof req.body === 'string' ? req.body : JSON.stringify(req.body || {})
  };
  try {
    const result = await mod.handler(event);
    const headers = result.headers || {};
    Object.keys(headers).forEach(h => res.setHeader(h, headers[h]));
    res.status(result.statusCode || 200).send(result.body || '');
  } catch (e) {
    res.status(500).json({ ok: false, message: 'Erreur serveur : ' + e.message });
  }
});

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'GAS 4.0 server' }));

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => {
  console.log(`Serveur GAS 4.0 démarré sur le port ${PORT}`);
  console.log(`URL à configurer côté application : http://votre-domaine:${PORT}/api`);
});
