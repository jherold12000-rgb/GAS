/* GAS — Gestion Administration Scolaire
   Implémentation de référence du contrat API universel (§14 du cahier des
   charges), sur Cloudflare Workers + KV. Ce n'est qu'UNE implémentation
   possible parmi d'autres (§7) : le client (server-adapter.js) ne connaît
   que le contrat /api/*, jamais Cloudflare en particulier. La même API
   pourrait être réécrite sur Node/Express, PHP, etc. sans toucher au
   frontend.

   Stockage KV (binding GAS_KV) :
     etab:<id>                 → { id, nom, dateCreation, ... }
     terminaux:<idEtab>        → [ { idTerminal, numero, ... }, ... ]
     licence:<idEtab>          → { statut, activatedAt, expiresAt, type }
     sync-ops:<idEtab>         → [ opération, ... ]  (liste append-only, taille bornée)
     conflits:<idEtab>         → [ conflit, ... ]
*/

const MAX_TERMINAUX = 3;
const MAX_OPS_CONSERVEES = 5000; // borne simple pour éviter une croissance illimitée de la clé KV

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) {
      try {
        return await handleAPI(request, env, url);
      } catch (e) {
        return json({ ok:false, error: String(e && e.message || e) }, 500);
      }
    }
    return env.ASSETS.fetch(request);
  }
};

function json(data, status) {
  return new Response(JSON.stringify(data), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json' }
  });
}

async function readBody(request) {
  try { return await request.json(); } catch (e) { return {}; }
}
async function kvGet(env, key, fallback) {
  const v = await env.GAS_KV.get(key);
  return v ? JSON.parse(v) : (fallback !== undefined ? fallback : null);
}
async function kvPut(env, key, value) {
  await env.GAS_KV.put(key, JSON.stringify(value));
}
function genId(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`.toUpperCase();
}

async function handleAPI(request, env, url) {
  const path = url.pathname.slice(5); // enlève "/api/"

  if (path === 'health') {
    return json({
      ok: true, app: 'GAS', apiVersion: '1',
      features: { licence: true, sync: true, terminals: true, conflicts: true }
    });
  }

  if (path === 'register-etablissement' && request.method === 'POST') {
    const body = await readBody(request);
    const id = genId('ETAB');
    const etab = { id, ...body, dateCreation: new Date().toISOString() };
    await kvPut(env, `etab:${id}`, etab);
    await kvPut(env, `terminaux:${id}`, []);
    return json({ ok: true, idEtablissement: id, etablissement: etab });
  }

  if (path === 'register-terminal' && request.method === 'POST') {
    const body = await readBody(request);
    const { idEtablissement, idInstallationTerminal, typeTerminal } = body;
    if (!idEtablissement) return json({ ok:false, message:'idEtablissement requis' }, 400);
    const terminaux = await kvGet(env, `terminaux:${idEtablissement}`, []);

    // §19 — un terminal déjà connu retrouve son numéro, pas de doublon créé.
    const existant = terminaux.find(t => t.idInstallationTerminal === idInstallationTerminal);
    if (existant) {
      existant.derniereActivite = new Date().toISOString();
      await kvPut(env, `terminaux:${idEtablissement}`, terminaux);
      return json({ ok:true, numeroTerminal: existant.numero, idTerminal: existant.idTerminal, refuse:false });
    }

    if (terminaux.length >= MAX_TERMINAUX) {
      // §19 — quatrième terminal refusé côté serveur.
      return json({ ok:true, refuse:true, message:`Limite de ${MAX_TERMINAUX} terminaux atteinte pour cet établissement.` });
    }

    const numero = terminaux.length + 1;
    const idTerminal = genId('TERM');
    terminaux.push({
      idTerminal, numero, idInstallationTerminal, typeTerminal: typeTerminal || 'Inconnu',
      dateEnregistrement: new Date().toISOString(), derniereActivite: new Date().toISOString(), statut: 'actif'
    });
    await kvPut(env, `terminaux:${idEtablissement}`, terminaux);
    return json({ ok:true, refuse:false, numeroTerminal: numero, idTerminal });
  }

  if (path === 'heartbeat' && request.method === 'POST') {
    const body = await readBody(request);
    const { idEtablissement, idInstallationTerminal } = body;
    if (!idEtablissement) return json({ ok:false }, 400);
    const terminaux = await kvGet(env, `terminaux:${idEtablissement}`, []);
    const t = terminaux.find(t => t.idInstallationTerminal === idInstallationTerminal);
    if (t) { t.derniereActivite = new Date().toISOString(); await kvPut(env, `terminaux:${idEtablissement}`, terminaux); }
    return json({ ok:true, serverNow: new Date().toISOString() });
  }

  if (path === 'licence-check' && request.method === 'POST') {
    const body = await readBody(request);
    const { idEtablissement } = body;
    const lic = await kvGet(env, `licence:${idEtablissement}`, null);
    if (!lic) return json({ ok:true, statut:'AUCUNE', serverNow: new Date().toISOString() });
    return json({ ok:true, ...lic, serverNow: new Date().toISOString(), statut: computeLicenceStatut(lic) });
  }

  if (path === 'licence-activate' && request.method === 'POST') {
    const body = await readBody(request);
    const { idEtablissement, cle } = body;
    if (!idEtablissement || !cle) return json({ ok:false, message:'Paramètres manquants' }, 400);
    const now = new Date();
    // §16 — licence annuelle : 12 mois à partir de l'activation valide.
    const expiresAt = new Date(now); expiresAt.setMonth(expiresAt.getMonth() + 12);
    const lic = { type:'annuelle', activatedAt: now.toISOString(), expiresAt: expiresAt.toISOString(), cle, statut:'ACTIVE' };
    await kvPut(env, `licence:${idEtablissement}`, lic);
    return json({ ok:true, ...lic, serverNow: now.toISOString() });
  }

  if (path === 'sync-push' && request.method === 'POST') {
    const body = await readBody(request);
    const { idEtablissement, operations } = body;
    if (!idEtablissement || !Array.isArray(operations)) return json({ ok:false }, 400);
    const key = `sync-ops:${idEtablissement}`;
    let ops = await kvGet(env, key, []);
    const idsConnus = new Set(ops.map(o => o.idOperation));
    for (const op of operations) { if (!idsConnus.has(op.idOperation)) ops.push(op); }
    if (ops.length > MAX_OPS_CONSERVEES) ops = ops.slice(ops.length - MAX_OPS_CONSERVEES);
    await kvPut(env, key, ops);
    return json({ ok:true, recu: operations.length });
  }

  if (path === 'sync-pull' && request.method === 'POST') {
    const body = await readBody(request);
    const { idEtablissement, depuis } = body;
    if (!idEtablissement) return json({ ok:false }, 400);
    const ops = await kvGet(env, `sync-ops:${idEtablissement}`, []);
    const filtrees = depuis ? ops.filter(o => o.dateHeure > depuis) : ops;
    return json({ ok:true, operations: filtrees, serverNow: new Date().toISOString() });
  }

  if (path === 'resolve-conflict' && request.method === 'POST') {
    const body = await readBody(request);
    const { idEtablissement } = body;
    const key = `conflits:${idEtablissement}`;
    const conflits = await kvGet(env, key, []);
    conflits.push({ ...body, date: new Date().toISOString() });
    await kvPut(env, key, conflits);
    return json({ ok:true });
  }

  if (path === 'terminaux-status' && (request.method === 'GET' || request.method === 'POST')) {
    const idEtablissement = url.searchParams.get('idEtablissement') || (await readBody(request)).idEtablissement;
    const terminaux = await kvGet(env, `terminaux:${idEtablissement}`, []);
    return json({ ok:true, terminaux });
  }

  return json({ ok:false, error:'Route inconnue' }, 404);
}

/* §16/§17 — règle de validité + tolérance de grâce jusqu'au 5 du mois
   suivant pour une signature mensuelle. Explicite et centralisée ici pour
   qu'il n'y ait aucune ambiguïté entre date d'activation, d'expiration et
   période de tolérance. */
function computeLicenceStatut(lic) {
  const now = new Date();
  const exp = new Date(lic.expiresAt);
  if (now <= exp) return 'ACTIVE';
  if (lic.type === 'mensuelle') {
    const toleranceFin = new Date(exp.getFullYear(), exp.getMonth() + 1, 5, 23, 59, 59);
    if (now <= toleranceFin) return 'TOLERANCE';
  }
  return 'EXPIRE';
}
