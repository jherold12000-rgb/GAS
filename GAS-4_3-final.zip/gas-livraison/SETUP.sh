#!/bin/bash
echo "GAS Application - Setup"
echo "======================="
echo ""

if [ ! -d "public" ]; then
    echo "Erreur : repertoire 'public' introuvable"
    exit 1
fi

if [ ! -d "instances" ]; then
    echo "Erreur : repertoire 'instances' introuvable"
    exit 1
fi

if [ ! -f "wrangler.toml" ]; then
    echo "Erreur : wrangler.toml introuvable a la racine (requis pour 'wrangler deploy' sans --config)"
    exit 1
fi

echo "Verification de la structure..."
if [ ! -f "public/index.html" ]; then
    echo "Erreur : public/index.html introuvable"
    exit 1
fi

if [ ! -f "instances/instance-worker.js" ]; then
    echo "Erreur : instances/instance-worker.js introuvable"
    exit 1
fi

if grep -q "COLLER_ICI_ID_DU_NAMESPACE" wrangler.toml; then
    echo "Attention : wrangler.toml contient encore un ID de namespace KV factice."
    echo "  Executez : wrangler kv namespace create GAS_KV"
    echo "  puis remplacez COLLER_ICI_ID_DU_NAMESPACE par l'ID obtenu."
fi

echo "Structure validee"
echo ""
echo "Pour deployer :"
echo "  wrangler deploy"
